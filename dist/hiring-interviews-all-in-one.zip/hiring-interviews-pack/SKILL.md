---
name: hiring-interviews-pack
description: "Drafts and checks the documents TA and HR teams write, 24 in all: Hiring Manager Intake, Role Success Profile, Essential Criteria Review, Interview Plan, Structured Interview Guide, Situational Questions, Work Sample Task, Question Fairness Check, Scoring Guide, Interviewer Note Sheet, Interviewer Briefing, Interviewer Practice Session, Interview Invitation, Advance Questions Sheet, Adjustment Request Reply, Candidate AI Use Statement, Interview Integrity Plan, Debrief Agenda, Decision Record, Reference Request, Candidate Feedback Note, Not Progressing Email, Candidate Experience Survey, Hiring Round Review. Use when TA and HR teams ask for any of these, or for help to agree what good looks like, write the questions, set up the scoring, prepare the candidate, run it and decide, close the loop."
---

# Hire on evidence

All 24 skills from pack 03 in one upload. Each skill's full instructions are in `skills/<slug>/INSTRUCTIONS.md`, with its sample input in that folder's `examples/`.

## How to use this bundle

1. Match the request to one skill in the table. If two fit, ask the user which they mean.
2. Read that skill's INSTRUCTIONS.md in full and follow it exactly. Paths inside it (`examples/...`, `templates/...`) are relative to that skill's own folder.
3. If nothing matches, say which skills come closest and what each produces.

## Skills

| # | Skill | Use it for | Instructions |
| --- | --- | --- | --- |
| 01 | Hiring Manager Intake | The scoping conversation: what this hire must do in year one, and what the job doesn't need. | `skills/hiring-manager-intake/INSTRUCTIONS.md` |
| 02 | Role Success Profile | Four to six criteria, each tied to real work, agreed before the first candidate. | `skills/role-success-profile/INSTRUCTIONS.md` |
| 03 | Essential Criteria Review | Finds essential criteria that shut people out without a job reason, and rewrites them. | `skills/essential-criteria-review/INSTRUCTIONS.md` |
| 04 | Interview Plan | Who assesses which criterion at which stage, so each one is tested once and properly. | `skills/interview-plan/INSTRUCTIONS.md` |
| 05 | Structured Interview Guide | The same questions in the same order for everyone, with probes and timings. | `skills/structured-interview-guide/INSTRUCTIONS.md` |
| 06 | Situational Questions | What-would-you-do questions built from the real dilemmas in the job. | `skills/situational-questions/INSTRUCTIONS.md` |
| 07 | Work Sample Task | A short task that mirrors the job and is hard to fake, with a marking guide. | `skills/work-sample-task/INSTRUCTIONS.md` |
| 08 | Question Fairness Check | Flags unlawful, leading or insider-friendly questions and rewrites them. | `skills/question-fairness-check/INSTRUCTIONS.md` |
| 09 | Scoring Guide | What a weak, sound and strong answer looks like for each criterion, before anyone interviews. | `skills/scoring-guide/INSTRUCTIONS.md` |
| 10 | Interviewer Note Sheet | A sheet that captures what the candidate said and did, kept apart from impressions. | `skills/interviewer-note-sheet/INSTRUCTIONS.md` |
| 11 | Interviewer Briefing | One page for the panel: roles, timings, questions to avoid, scoring alone first. | `skills/interviewer-briefing/INSTRUCTIONS.md` |
| 12 | Interviewer Practice Session | A 60-minute session where hiring managers practise asking, probing and scoring. | `skills/interviewer-practice-session/INSTRUCTIONS.md` |
| 13 | Interview Invitation | Date, format, panel and what to expect, with a plain way to ask for adjustments. | `skills/interview-invitation/INSTRUCTIONS.md` |
| 14 | Advance Questions Sheet | The questions or themes you share ahead, sent the same way to every candidate. | `skills/advance-questions-sheet/INSTRUCTIONS.md` |
| 15 | Adjustment Request Reply | A reply that agrees adjustments to the interview without asking for a diagnosis. | `skills/adjustment-request-reply/INSTRUCTIONS.md` |
| 16 | Candidate AI Use Statement | What AI use is fine in your process, what isn't, and how the interview checks. | `skills/candidate-ai-use-statement/INSTRUCTIONS.md` |
| 17 | Interview Integrity Plan | Proportionate checks for stand-in candidates and live AI help, the same for everyone. | `skills/interview-integrity-plan/INSTRUCTIONS.md` |
| 18 | Debrief Agenda | Scores in before anyone talks, then criterion by criterion, with the decision written down. | `skills/debrief-agenda/INSTRUCTIONS.md` |
| 19 | Decision Record | Why the panel decided, criterion by criterion, ready for a subject access request. | `skills/decision-record/INSTRUCTIONS.md` |
| 20 | Reference Request | Reference questions tied to the criteria, asked with the candidate's consent. | `skills/reference-request/INSTRUCTIONS.md` |
| 21 | Candidate Feedback Note | Specific, kind feedback written from the panel's evidence and decision. | `skills/candidate-feedback-note/INSTRUCTIONS.md` |
| 22 | Not Progressing Email | Prompt, human messages for each stage, so no candidate is left waiting. | `skills/not-progressing-email/INSTRUCTIONS.md` |
| 23 | Candidate Experience Survey | A short survey after interview on what it was like and what to fix. | `skills/candidate-experience-survey/INSTRUCTIONS.md` |
| 24 | Hiring Round Review | A look back at one round in aggregate: time to hire, drop-off, score spread, consistency. | `skills/hiring-round-review/INSTRUCTIONS.md` |

## The one rule

Claude drafts the questions, guides and letters. Interviewers gather the evidence, and people make every hiring decision.
